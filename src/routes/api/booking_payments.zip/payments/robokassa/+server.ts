import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { createPayment } from '$lib/server/robokassa.server';

export const POST: RequestHandler = async ({ request }) => {
	const { amount, description, email } = await request.json();

	if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
		return json({ error: 'Некорректная сумма' }, { status: 400 });
	}

	const outSum = parseFloat(amount).toFixed(2);
	const result = await createPayment({
		outSum,
		description: description || 'Оплата консультации',
		email: email || undefined
	});

	return json(result);
};
