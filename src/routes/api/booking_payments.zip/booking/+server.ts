import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { createBooking } from '$lib/server/booking.server';

export const POST: RequestHandler = async ({ request, url }) => {
	const { availabilityId, bookedAt, clientName, email } = await request.json();

	if (!availabilityId || !bookedAt || !clientName?.trim() || !email?.trim()) {
		return json({ error: 'Заполните все поля' }, { status: 400 });
	}

	if (!email.includes('@')) {
		return json({ error: 'Некорректный email' }, { status: 400 });
	}

	if (isNaN(new Date(bookedAt).getTime())) {
		return json({ error: 'Некорректное время слота' }, { status: 400 });
	}

	try {
		const payment = await createBooking({
			availabilityId: Number(availabilityId),
			bookedAt,
			clientName: clientName.trim(),
			email: email.trim(),
			originUrl: url.origin
		});
		return json(payment);
	} catch (err) {
		const message = err instanceof Error ? err.message : 'Ошибка сервера';
		return json({ error: message }, { status: 400 });
	}
};
